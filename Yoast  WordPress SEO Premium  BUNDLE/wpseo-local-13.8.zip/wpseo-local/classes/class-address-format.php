<?php
/**
 * Yoast SEO: Local plugin file.
 *
 * @package WPSEO_Local\Main
 */

use Yoast\WP\Local\Formatters\Address_Formatter;

/**
 * Class WPSEO_Local_Address_Format
 *
 * @deprecated Use \Yoast\WP\Local\Formatters\Address_Formatter instead
 */
class WPSEO_Local_Address_Format extends Address_Formatter {

}
