<div  class="twentytwenty-container {{ extra_class }} {{ css }}" data-default_offset_pct="{{ default_offset }}" data-orientation="{{ orientation }}">
    <img src="{{ before_image }}">
    <img src="{{ after_image }}">
</div>
